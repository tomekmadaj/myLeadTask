@extends('layouts.app')

@section('content')

<div class="container">
    <h1>yo</h1>
</div>

@endsection
