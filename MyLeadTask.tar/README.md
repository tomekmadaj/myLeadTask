## About

Login
User: menager@mylead.global
pass: menagermylead

Database: \MyLead_task\database\mylead.sql 
